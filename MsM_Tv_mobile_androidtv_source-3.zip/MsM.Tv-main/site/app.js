const PLAYLIST_URL = "https://raw.githubusercontent.com/mdmasumrana1580-design/Playlist-/refs/heads/main/Playlist";
const PLAYLIST_CACHE_KEY = "vip-network-last-good-playlist-v1";
const PLAYLIST_REFRESH_MS = 10 * 60 * 1000;
const STREAM_FALLBACK_URL = "https://mp3tourl.com/videos/1789615987340-af8196aa-b471-46d6-b1a6-ce56f31a1da8.mp4";
const VIP_WORKER_API = window.VIP_WORKER_API || "";

let channels = [];
let current = "All";
let hls = null;
let currentChannelIndex = -1;
let visibleChannels = [];
let catalogueRenderLimit = 60;
const CATALOGUE_PAGE_SIZE = 60;
let playerReturnScrollY = 0;
let playerReturnGridScrollTop = 0;
let playerFullscreenGridScrollTop = 0;
let playerOpenedFromCard = false;

// Free/Paid channel display rules. These 19 channels are FREE by default; all others are PAID.
const FREE_DEFAULTS = ['A Sports HD','ATN Bangla','BTV','Makkah Live','Independent','RTV','Ananda TV','HUM TV','Sony Max 2','Sony Aath','Enter 10 Bangla','Zee Bangla HD','B4U Music','Sony YaY','9XM','T Sports HD','Star Sports SL 2','Sony Ten 1','Star Sports 1'];
let channelAccess = {};
function normalizeAccessName(v){ return String(v || '').replace(/\s+/g,' ').trim().toLowerCase(); }
function defaultChannelAccess(name){ const n=normalizeAccessName(name); return FREE_DEFAULTS.some(x=>normalizeAccessName(x)===n)?'free':'paid'; }
function getChannelAccess(name){ const k=normalizeAccessName(name); return Object.prototype.hasOwnProperty.call(channelAccess,k) ? (channelAccess[k]==='free'?'free':'paid') : defaultChannelAccess(name); }
async function loadChannelAccess(){
  try {
    const base=(VIP_WORKER_API || location.origin).replace(/\/$/,'');
    const r=await fetch(base+'/api/admin/settings',{cache:'no-store'});
    if(!r.ok) return;
    const d=await r.json(); const s=d && (d.settings || d);
    channelAccess=s && s.channelAccess && typeof s.channelAccess==='object' ? s.channelAccess : {};
  } catch(e) { channelAccess={}; }
}

const grid = document.getElementById("grid");
const empty = document.getElementById("empty");
const channelSearch = document.getElementById("channelSearch");
const channelFooter = document.querySelector(".site-footer");
const video = document.getElementById("video");
const section = document.getElementById("playerSection");
const welcomeVideo = document.getElementById("welcomeVideo");
const videoBox = document.querySelector(".video-box");
if (welcomeVideo) {
  welcomeVideo.muted = true;
  welcomeVideo.defaultMuted = true;
  welcomeVideo.playsInline = true;
  if (videoBox) videoBox.classList.add("welcome-active");
  const liveBadge = document.getElementById("liveBadge");
  if (liveBadge) liveBadge.style.display = "none";
  const hideWelcome = function () {
    welcomeVideo.classList.add("welcome-hidden");
    if (videoBox) videoBox.classList.remove("welcome-active");
  };
  welcomeVideo.addEventListener("ended", hideWelcome, {once:true});
  welcomeVideo.addEventListener("error", hideWelcome, {once:true});
  welcomeVideo.load();
  const startWelcome = function () {
    const p = welcomeVideo.play();
    if (p && p.catch) p.catch(function () {
      // Keep the intro visible; a muted MP4 is allowed to autoplay on supported browsers.
    });
  };
  welcomeVideo.addEventListener("loadeddata", startWelcome, {once:true});
  setTimeout(startWelcome, 150);
}

// Compact visitor stats in the header.
// Total visitors uses the current key-free Abacus counter service.
// Online visitors needs a real-time tracking backend; until one is connected,
// the UI shows a dash instead of displaying a misleading/fake number.
const VISITOR_COUNTER_KEY = "vip-network-masum-2026-total-visitors";
const VISITOR_COUNTER_API = "https://abacus.jasoncameron.dev";

function updateHeaderVisitor(value) {
  const el = document.getElementById("headerTotalVisitors");
  if (!el) return;
  const n = Number(value);
  el.textContent = Number.isFinite(n) ? n.toLocaleString("en-US") : "—";
}

function updateOnlineVisitors(value) {
  const el = document.getElementById("headerOnlineVisitors");
  if (!el) return;
  const n = Number(value);
  el.textContent = Number.isFinite(n) ? n.toLocaleString("en-US") : "—";
}

async function initVisitorCounter() {
  const sessionKey = "vipVisitorCounted";
  try {
    const counted = sessionStorage.getItem(sessionKey);
    let data;
    if (!counted) {
      const hit = await fetch(VISITOR_COUNTER_API + "/hit/" + encodeURIComponent("vip-network-masum-2026") + "/" + encodeURIComponent("total"), {
        method: "GET", cache: "no-store"
      });
      if (!hit.ok) throw new Error("counter hit failed: " + hit.status);
      data = await hit.json();
      sessionStorage.setItem(sessionKey, "1");
    } else {
      const current = await fetch(VISITOR_COUNTER_API + "/get/" + encodeURIComponent("vip-network-masum-2026") + "/" + encodeURIComponent("total"), {
        method: "GET", cache: "no-store"
      });
      if (!current.ok) throw new Error("counter get failed: " + current.status);
      data = await current.json();
    }
    updateHeaderVisitor(data.value);
  } catch (error) {
    console.warn("Visitor counter unavailable", error);
  }

  // Real online visitors: every browser gets a temporary ID and sends a heartbeat.
  // The Worker stores it in KV for 60 seconds, then /api/online returns the active count.
  const onlineApi = (window.VIP_WORKER_API || window.location.origin).replace(/\/$/, "");
  let onlineId = localStorage.getItem("vipOnlineId");
  if (!onlineId) {
    onlineId = (crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2) + Date.now());
    localStorage.setItem("vipOnlineId", onlineId);
  }

  const refreshOnline = async function () {
    try {
      await fetch(onlineApi + "/api/online/ping", {
        method: "POST",
        headers: {"content-type":"application/json"},
        body: JSON.stringify({id: onlineId}),
        cache: "no-store"
      });
      const r = await fetch(onlineApi + "/api/online", {cache:"no-store"});
      if (!r.ok) throw new Error("online endpoint: " + r.status);
      const d = await r.json();
      updateOnlineVisitors(d.online);
    } catch (e) {
      console.warn("Online counter unavailable", e);
      updateOnlineVisitors(null);
    }
  };

  refreshOnline();
  setInterval(refreshOnline, 20000);
}

initVisitorCounter();

// Premium overlay controls: click/tap the video to show, tap again to hide.
const vipVideoBox = document.getElementById("vipVideoBox");
const vipBottomControls = document.getElementById("vipBottomControls");
const vipMute = document.getElementById("vipMute");
const vipVolume = document.getElementById("vipVolume");
const vipFullscreen = document.getElementById("vipFullscreen");
const vipFullscreenLauncher = document.getElementById("vipFullscreenLauncher");
let vipControlsTimer = null;

function showVipControls() {
  if (!vipVideoBox) return;
  vipVideoBox.classList.add("vip-controls-visible");
  if (vipControlsTimer) clearTimeout(vipControlsTimer);
  vipControlsTimer = setTimeout(function(){
    vipVideoBox.classList.remove("vip-controls-visible");
  }, 4000);
}
function toggleVipControls() {
  if (!vipVideoBox) return;
  if (vipVideoBox.classList.contains("vip-controls-visible")) {
    vipVideoBox.classList.remove("vip-controls-visible");
    if (vipControlsTimer) clearTimeout(vipControlsTimer);
  } else {
    showVipControls();
  }
}

if (vipVideoBox) {
  vipVideoBox.addEventListener("click", function(e) {
    if (e.target.closest("button,input,.plyr__controls,.landscape-channel-controls,.vip-bottom-controls")) return;
    toggleVipControls();
  });
}

if (vipMute) vipMute.addEventListener("click", function(e){
  e.preventDefault(); e.stopPropagation();
  video.muted = !video.muted;
  vipMute.textContent = video.muted || video.volume === 0 ? "🔇" : "🔊";
  showVipControls();
});
if (vipVolume) vipVolume.addEventListener("input", function(e){
  e.stopPropagation();
  video.volume = Number(vipVolume.value);
  video.muted = video.volume === 0;
  vipMute.textContent = video.muted ? "🔇" : "🔊";
  showVipControls();
});
if (vipFullscreenLauncher) vipFullscreenLauncher.addEventListener("click", function(e){
  e.preventDefault(); e.stopPropagation();
  toggleNativeFullscreen();
  showVipControls();
});
if (vipFullscreen) vipFullscreen.addEventListener("click", function(e){
  e.preventDefault(); e.stopPropagation();
  toggleNativeFullscreen();
  showVipControls();
});

video.addEventListener("volumechange", function(){
  if (vipVolume) vipVolume.value = String(video.volume);
  if (vipMute) vipMute.textContent = video.muted || video.volume === 0 ? "🔇" : "🔊";
});


function esc(value) {
  return String(value || "").replace(/[&<>"']/g, function (m) {
    return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m];
  });
}

function normalizeCategoryKey(value) {
  const v = String(value || "").trim().toUpperCase();
  if (v === "ALL") return "ALL";
  if (v === "SPORTS" || v === "SPORT") return "SPORTS";
  if (v === "BD" || v === "BANGLADESH") return "BD";
  if (v === "INDIA" || v === "INDIAN") return "INDIA";
  if (v === "OTHER" || v === "OTHERS") return "OTHER";
  if (v === "MOVIE & SERIES" || v === "MOVIES & SERIES" || v === "MOVIE" || v === "MOVIES" || v === "SERIES") return "MOVIE & SERIES";
  return v;
}

function catFor(name, group) {
  const rawGroup = String(group || "").trim();
  const groupKey = normalizeCategoryKey(rawGroup);

  // Always trust an explicit playlist category/group first.
  // This prevents a Live TV channel whose name contains words like
  // "movie" or "series" from being moved into Movie & Series.
  if (["SPORTS", "BD", "INDIA", "OTHER", "MOVIE & SERIES"].includes(groupKey)) {
    return groupKey;
  }

  const text = ((name || "") + " " + rawGroup).toLowerCase();

  // Only infer Movie & Series when there is no canonical explicit category.
  if (/movie\s*(?:&|and)\s*series|movies?\s*(?:&|and)\s*series|\bseries\b|\bmovie\b|\bmovies\b|cinema|film|netflix|prime\s*video|hoichoi|bioscope/.test(text)) {
    return "MOVIE & SERIES";
  }

  // SPORTS comes first, so sports channels stay together even if they are BD/India.
  if (/sport|cricket|football|fifa|eurosport|willow|ten\s*cricket|ptv\s*sports|tsn|espn|bein|wwe|golf|nfl|nba/.test(text)) {
    return "SPORTS";
  }

  // Bangladesh channels
  if (/bangla|bangladesh|bd\b|somoy|jamuna|ekattor|ekattor tv|dbc|maasranga|atn|channel\s*24|news24|independent|ntv|rtv|banglavision|boishakhi|gazi tv|gtv|b tv|bengal|duronto|deepto|nagorik|mohona|asian tv|desh tv|bijoy tv|mytv|satv|ekushey|bishwa|bangla tv|btv/.test(text)) {
    return "BD";
  }

  // India channels
  if (/india|indian|sony|zee|star|colors|set\b|sab\b|aaj tak|ndtv|republic|news18|times now|india tv|dd national|dd sports|sun tv|asianet|vijay|jaya|starplus|star gold|sony max|sony pix|sony wah|sony yay|sony pal|&pictures|b4u|movies now|mnx|hbo india/.test(text)) {
    return "INDIA";
  }

  return "OTHER";
}

function parseM3U(text) {
  const lines = String(text || "").replace(/\r/g, "").split("\n");
  const out = [];
  let meta = null;

  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;

    if (line.startsWith("#EXTINF")) {
      const comma = line.indexOf(",");
      const name = comma >= 0 ? line.slice(comma + 1).trim() : "Live Channel";
      const groupMatch = line.match(/group-title="([^"]*)"/i);
      const logoMatch = line.match(/tvg-logo="([^"]*)"/i);

      meta = {
        name: name || "Live Channel",
        group: groupMatch ? groupMatch[1] : "",
        logo: logoMatch ? logoMatch[1] : ""
      };
      continue;
    }

    if (line.startsWith("#")) continue;

    if (meta) {
      if (/^(https?|rtmp|rtsp|hls):\/\//i.test(line)) {
        out.push({
          name: meta.name,
          cat: catFor(meta.name, meta.group),
          url: line,
          logo: meta.logo
        });
      }
      meta = null;
    }
  }

  return out;
}


function fitChannelLabels(root) {
  const scope = root || document;
  scope.querySelectorAll(".label").forEach(function (label) {
    const text = label.querySelector(".label-text");
    if (!text) return;

    text.style.transform = "none";
    text.style.fontSize = "";

    const available = Math.max(1, label.clientWidth - 8);
    const baseSize = parseFloat(getComputedStyle(label).fontSize) || 10;
    let size = baseSize;

    text.style.fontSize = size + "px";

    // First reduce the font slightly for long names.
    while (text.scrollWidth > available && size > 7) {
      size -= 0.5;
      text.style.fontSize = size + "px";
    }

    // If it is still too long, scale the text horizontally just enough
    // to keep the complete name visible inside the same badge.
    if (text.scrollWidth > available) {
      const scale = Math.max(0.35, available / text.scrollWidth);
      text.style.transform = "scaleX(" + scale + ")";
    }
  });
}

function ensureRgbLoadMoreStyle() {
  if (document.getElementById("rgbLoadMoreStyle")) return;
  const style = document.createElement("style");
  style.id = "rgbLoadMoreStyle";
  style.textContent = `
    .catalogue-load-more[hidden] { display: none !important; }
    .catalogue-load-more { background: transparent !important; border: 0 !important; box-shadow: none !important; color: #fff; font-weight: 800 !important; letter-spacing: .2px; text-shadow: none !important; animation: msmtv-rgb-text 3.2s linear infinite; -webkit-tap-highlight-color: transparent; }
    .catalogue-load-more:focus-visible { outline: 2px solid #fff; outline-offset: 4px; }
    @keyframes msmtv-rgb-text { 0%{color:#fff} 16%{color:#ff3434} 33%{color:#ffdf35} 50%{color:#24f06a} 66%{color:#32dfff} 83%{color:#b45cff} 100%{color:#fff} }
  `;
  document.head.appendChild(style);
}

function render() {
  ensureRgbLoadMoreStyle();
  const q = channelSearch ? channelSearch.value.trim().toLocaleLowerCase() : "";
  grid.innerHTML = "";
  const selectedCategory = normalizeCategoryKey(current);
  const list = channels.filter(function (c) {
    const categoryOk = q ? true : (selectedCategory === "ALL" || normalizeCategoryKey(c.cat) === selectedCategory);
    const name = String(c.name || "").trim().toLocaleLowerCase();
    const searchOk = !q || name.startsWith(q);
    return categoryOk && searchOk;
  });
  visibleChannels = list;
  empty.hidden = list.length > 0;
  if (!list.length) empty.textContent = channels.length ? "দুঃখিত! কোনো চ্যানেল পাওয়া যায়নি" : "Loading channels...";

  // Render only a small batch of cards. The complete catalogue remains searchable/playable,
  // while the DOM stays lightweight for large Movie & Series playlists.
  const shown = list.slice(0, catalogueRenderLimit);
  shown.forEach(function (c) {
    const el = document.createElement("article");
    el.className = "card";
    const icon = c.logo
      ? '<img src="' + esc(c.logo) + '" alt="" loading="lazy" decoding="async">'
      : "<span>TV</span>";
    el.innerHTML =
      '<div class="circle">' + icon + '</div>' +
      '<img class="vip-paid-crown" loading="lazy" src="https://i.postimg.cc/g05JdqSY/Blue-Star-symbol.png" alt="Channel star" title="Channel">' +
      '<div class="label"><span class="label-text">' + esc(c.name) + '</span></div>';
    el.addEventListener("click", function (e) { e.preventDefault(); play(c, el, false, true); });
    grid.appendChild(el);
    fitChannelLabels(el);
  });

  let more = document.getElementById("catalogueLoadMore");
  if (!more) {
    more = document.createElement("button");
    more.id = "catalogueLoadMore";
    more.type = "button";
    more.className = "catalogue-load-more";
    more.style.cssText = "margin:18px auto;padding:12px 22px;background:transparent;border:0;box-shadow:none;font-weight:800;cursor:pointer";
    more.addEventListener("click", function () {
      // Preserve the channel-list scroll position while appending the next batch.
      const previousScrollTop = grid.scrollTop;
      catalogueRenderLimit += CATALOGUE_PAGE_SIZE;
      render();
      requestAnimationFrame(function () {
        grid.scrollTop = previousScrollTop;
      });
    });
  }
  // Keep the count/load-more control inside the scrollable channel list.
  more.hidden = shown.length >= list.length;
  more.textContent = "আরও দেখুন (" + shown.length + "/" + list.length + ")";
  grid.appendChild(more);

  // Copyright belongs after the channel catalogue, not over the first row.
  if (channelFooter) grid.appendChild(channelFooter);
}

function play(c, clickedCard, retryOriginal, fromUserClick) {
  if (!retryOriginal && !playerOpenedFromCard) {
    playerReturnScrollY = window.scrollY || window.pageYOffset || 0;
    playerReturnGridScrollTop = grid ? grid.scrollTop : 0;
    playerOpenedFromCard = true;
  }
  currentChannelIndex = visibleChannels.indexOf(c);
  if (welcomeVideo) welcomeVideo.classList.add("welcome-hidden");
  if (videoBox) videoBox.classList.remove("welcome-active");

  // Always open/show the player before touching the stream source.
  section.hidden = false;
  section.removeAttribute("hidden");
  section.style.display = "block";
  section.style.visibility = "visible";
  if (clickedCard) clickedCard.setAttribute("aria-current", "true");
  document.getElementById("playerTitle").textContent = c.name || "Live Player";
  document.getElementById("note").style.display = "none";

  const liveBadge = document.getElementById("liveBadge");
  if (liveBadge) liveBadge.style.display = "flex";

  if (hls) { try { hls.destroy(); } catch (e) {} hls = null; }

  const isMovieSeries = normalizeCategoryKey(c.cat) === "MOVIE & SERIES";
  if (videoBox) videoBox.classList.toggle("movie-native-player", isMovieSeries);
  // Movie & Series needs the browser's native timeline so viewers can seek forward/backward.
  // Keep native controls disabled for live channels, where seeking is not supported.
  video.controls = isMovieSeries;
  video.setAttribute("playsinline", "");
  video.autoplay = true;
  video.playsInline = true;
  video.muted = false;
  video.volume = 1;
  video.style.visibility = "visible";
  video.style.opacity = "1";
  video.style.display = "block";

  video.pause();
  video.removeAttribute("src");
  video.load();

  const originalUrl = String(c.url || "").trim();
  let fallbackUsed = !retryOriginal && c._usingFallback === true;
  const sourceUrl = fallbackUsed ? STREAM_FALLBACK_URL : originalUrl;
  // HTTPS pages cannot play HTTP media directly (mixed-content blocking).
  // Route all HTTP media through the site's HTTPS stream proxy; keep HTTPS URLs direct.
  const playbackUrl = /^http:\/\//i.test(sourceUrl)
    ? (location.origin + '/api/stream-proxy?url=' + encodeURIComponent(sourceUrl))
    : sourceUrl;

  function showPlaybackError() {
    const note = document.getElementById("note");
    note.textContent = "ভিডিও চালু করা যাচ্ছে না।";
    note.style.display = "block";
  }

  function startPlayback() {
    if (!sourceUrl) { showPlaybackError(); return; }
    const p = video.play();
    if (p && p.catch) p.catch(function(err) {
      // Do not replace a real stream just because Chrome blocked autoplay.
      // The user can press the native Play button for Movie & Series.
      // Chrome may reject autoplay; the stream is still loaded and can be started by the player control.
      if (fromUserClick) showPlaybackError();
    });
  }

  function switchToFallback() {
    if (fallbackUsed) { showPlaybackError(); return; }
    fallbackUsed = true;
    c._usingFallback = true;
    if (hls) { try { hls.destroy(); } catch (e) {} hls = null; }
    video.pause();
    video.removeAttribute("src");
    video.load();
    video.src = STREAM_FALLBACK_URL;
    video.addEventListener("loadedmetadata", startPlayback, {once:true});
    video.addEventListener("canplay", startPlayback, {once:true});
    startPlayback();
  }

  // HLS streams: use hls.js on Chrome/Edge/Firefox and native HLS where available.
  if (/\.m3u8(?:\?|$)/i.test(sourceUrl)) {
    if (window.Hls && Hls.isSupported()) {
      hls = new Hls({ enableWorker:true, lowLatencyMode:true, backBufferLength:30 });
      hls.attachMedia(video);
      hls.on(Hls.Events.MEDIA_ATTACHED, function() {
        if (hls) hls.loadSource(playbackUrl);
      });
      hls.on(Hls.Events.MANIFEST_PARSED, function() {
        startPlayback();
      });
      hls.on(Hls.Events.ERROR, function(_event, data) {
        if (!data || !data.fatal || !hls) return;
        if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
          try { hls.recoverMediaError(); } catch(e) { switchToFallback(); }
        } else {
          switchToFallback();
        }
      });
    } else {
      // Safari/iOS can play HLS directly.
      video.src = playbackUrl;
      video.addEventListener("loadedmetadata", startPlayback, {once:true});
      video.addEventListener("error", function(){ showPlaybackError(); }, {once:true});
      video.load();
    }
  } else {
    // MP4 and other browser-native formats.
    video.src = playbackUrl;
    video.addEventListener("loadedmetadata", startPlayback, {once:true});
    video.addEventListener("canplay", startPlayback, {once:true});
    video.addEventListener("error", function() {
      if (!fallbackUsed) switchToFallback(); else showPlaybackError();
    }, {once:true});
    video.load();
    startPlayback();
  }
}

async function requestNativeFullscreen() {
  if (!videoBox) return;
  try {
    if (videoBox.requestFullscreen) {
      await videoBox.requestFullscreen({ navigationUI: "hide" });
      return;
    }
    if (videoBox.webkitRequestFullscreen) {
      videoBox.webkitRequestFullscreen();
      return;
    }
  } catch (e) {
    // Fall through to CSS fullscreen if native fullscreen is unavailable/blocked.
  }
  videoBox.classList.add("vip-css-fullscreen", "vip-fullscreen", "is-fullscreen");
  document.body.classList.add("vip-player-fullscreen");
}

async function exitNativeFullscreen() {
  try {
    if (document.fullscreenElement && document.exitFullscreen) {
      await document.exitFullscreen();
    } else if (document.webkitFullscreenElement && document.webkitExitFullscreen) {
      document.webkitExitFullscreen();
    }
  } catch (e) {}
  if (videoBox) {
    videoBox.classList.remove("vip-css-fullscreen", "vip-fullscreen", "is-fullscreen");
  }
  document.body.classList.remove("vip-player-fullscreen");
}

function isBrowserNativeFullscreen() {
  return !!(document.fullscreenElement || document.webkitFullscreenElement);
}

function isCssPlayerFullscreen() {
  return !!(videoBox && videoBox.classList.contains("vip-css-fullscreen"));
}

function isNativeFullscreen() {
  return isBrowserNativeFullscreen() || isCssPlayerFullscreen();
}

// Important: native fullscreen and our CSS fullscreen are two different states.
// Android can exit native fullscreen with its Back button without removing our
// CSS class. Never treat that stale class as proof that native fullscreen is active.
function cleanupAfterNativeFullscreenExit() {
  if (isBrowserNativeFullscreen()) return;
  if (videoBox) {
    videoBox.classList.remove("vip-css-fullscreen", "vip-fullscreen", "is-fullscreen", "vip-orientation-fallback");
  }
  document.body.classList.remove("vip-player-fullscreen");
  try { if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock(); } catch (e) {}
}

async function toggleNativeFullscreen() {
  const wasPlaying = !video.paused && !video.ended;
  if (isNativeFullscreen()) {
    await exitNativeFullscreen();
    try { if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock(); } catch (e) {}
    restorePlayerGridScroll();
  } else {
    playerFullscreenGridScrollTop = grid ? grid.scrollTop : playerReturnGridScrollTop;
    await requestNativeFullscreen();
    try {
      if (screen.orientation && screen.orientation.lock) await screen.orientation.lock("landscape");
    } catch (e) {}
  }
  syncFullscreenState();
  setTimeout(syncFullscreenState, 120);
  setTimeout(syncFullscreenState, 500);
  if (wasPlaying && video.paused) {
    const p = video.play();
    if (p && p.catch) p.catch(function(){});
  }
}

function setFullscreenButtonState() {
  const isFs = isNativeFullscreen();
  if (videoBox) {
    videoBox.classList.toggle("vip-fullscreen", isFs);
    videoBox.classList.toggle("is-fullscreen", isFs);
    videoBox.classList.toggle("vip-css-fullscreen", isFs);
  }
  document.body.classList.toggle("vip-player-fullscreen", isFs);
  const controls = document.getElementById("landscapeChannelControls");
  if (controls) controls.setAttribute("aria-hidden", isFs ? "false" : "true");
}

function restorePlayerGridScroll() {
  if (!grid) return;
  const target = Number.isFinite(playerFullscreenGridScrollTop)
    ? playerFullscreenGridScrollTop
    : playerReturnGridScrollTop;
  requestAnimationFrame(function () {
    grid.scrollTop = target;
    requestAnimationFrame(function () { grid.scrollTop = target; });
  });
}

function syncFullscreenState() {
  setFullscreenButtonState();
  requestAnimationFrame(setFullscreenButtonState);
}

function changeChannel(step) {
  if (!visibleChannels.length) return;
  let i = currentChannelIndex;
  if (i < 0) i = 0;
  i = (i + step + visibleChannels.length) % visibleChannels.length;
  currentChannelIndex = i;
  const wasFs = isNativeFullscreen() || (videoBox && videoBox.classList.contains("vip-css-fullscreen"));
  play(visibleChannels[i], null);
  if (wasFs) {
    // Reassert the overlay after the stream source changes.
    setTimeout(syncFullscreenState, 50);
  }
}

document.getElementById("prevChannel").addEventListener("click", function(e) {
  e.preventDefault(); e.stopPropagation(); changeChannel(-1); showVipControls();
});
document.getElementById("nextChannel").addEventListener("click", function(e) {
  e.preventDefault(); e.stopPropagation(); changeChannel(1); showVipControls();
});

window.addEventListener("orientationchange", function () {
  syncFullscreenState();
  setTimeout(function () { if (!isNativeFullscreen()) restorePlayerGridScroll(); }, 150);
  setTimeout(function () { if (!isNativeFullscreen()) restorePlayerGridScroll(); }, 600);
});
document.addEventListener("fullscreenchange", function () {
  cleanupAfterNativeFullscreenExit();
  syncFullscreenState();
  if (!isBrowserNativeFullscreen()) {
    restorePlayerGridScroll();
    setTimeout(restorePlayerGridScroll, 150);
    setTimeout(restorePlayerGridScroll, 600);
  }
});
document.addEventListener("webkitfullscreenchange", function () {
  cleanupAfterNativeFullscreenExit();
  syncFullscreenState();
  if (!isBrowserNativeFullscreen()) {
    restorePlayerGridScroll();
    setTimeout(restorePlayerGridScroll, 150);
    setTimeout(restorePlayerGridScroll, 600);
  }
});
syncFullscreenState();

function closePlayer() {
  if (hls) {
    hls.destroy();
    hls = null;
  }

  video.pause();
  video.removeAttribute("src");
  video.load();
  video.style.visibility = "hidden";
  video.style.opacity = "0";

  // Close the player and return to the exact channel-grid position.
  section.hidden = true;
  section.style.display = "none";
  if (welcomeVideo) welcomeVideo.classList.add("welcome-hidden");
  if (videoBox) videoBox.classList.remove("welcome-active");

  const y = playerReturnScrollY;
  const gridY = playerReturnGridScrollTop;
  playerOpenedFromCard = false;
  requestAnimationFrame(function(){
    window.scrollTo({top:y, left:0, behavior:"auto"});
    if (grid) grid.scrollTop = gridY;
    requestAnimationFrame(function(){
      window.scrollTo({top:y, left:0, behavior:"auto"});
      if (grid) grid.scrollTop = gridY;
    });
  });
}

document.getElementById("closePlayer").addEventListener("click", closePlayer);

document.querySelectorAll("#cats button").forEach(function (button) {
  button.addEventListener("click", function () {
    document.querySelectorAll("#cats button").forEach(function (b) {
      b.classList.remove("active");
    });

    button.classList.add("active");
    current = normalizeCategoryKey(button.dataset.cat);
    catalogueRenderLimit = CATALOGUE_PAGE_SIZE;
    render();
  });
});

if (channelSearch) {
  channelSearch.addEventListener("input", function () {
    currentChannelIndex = -1;
    render();
  });
}

empty.hidden = false;
empty.textContent = "Loading channels...";

function currentChannelUrl() {
  const c = visibleChannels[currentChannelIndex];
  return c && c.url ? c.url : "";
}

function currentChannelName() {
  const c = visibleChannels[currentChannelIndex];
  return c && c.name ? c.name : "";
}

async function fetchPlaylistFromGithub() {
  const response = await fetch(PLAYLIST_URL, {
    cache: "no-store",
    headers: {"cache-control":"no-cache"}
  });
  if (!response.ok) throw new Error("GitHub playlist load failed: " + response.status);
  const parsed = parseM3U(await response.text());
  if (!parsed.length) throw new Error("GitHub playlist is empty or invalid");
  return parsed;
}

function saveLastGoodPlaylist(list) {
  try {
    localStorage.setItem(PLAYLIST_CACHE_KEY, JSON.stringify({
      savedAt: Date.now(),
      channels: list
    }));
  } catch (e) {
    console.warn("Could not cache playlist", e);
  }
}

function loadLastGoodPlaylist() {
  try {
    const raw = localStorage.getItem(PLAYLIST_CACHE_KEY);
    if (!raw) return [];
    const data = JSON.parse(raw);
    return Array.isArray(data && data.channels) ? data.channels : [];
  } catch (e) {
    return [];
  }
}

async function loadVipPlaylist() {
  try {
    const fresh = await fetchPlaylistFromGithub();
    saveLastGoodPlaylist(fresh);
    return fresh;
  } catch (githubError) {
    console.warn("GitHub playlist unavailable; using last successful playlist.", githubError);
  }

  const cached = loadLastGoodPlaylist();
  if (cached.length) return cached;

  const apiBase = (window.VIP_WORKER_API || "").replace(/\/$/, "");
  if (apiBase) {
    try {
      const r = await fetch(apiBase + "/api/playlist", {cache:"no-store"});
      if (r.ok) {
        const data = await r.json();
        const list = Array.isArray(data?.channels) ? data.channels : [];
        if (list.length) {
          return list.map(function(c){
            return {
              name:c.name||"Live Channel",
              cat:normalizeCategoryKey(c.category || catFor(c.name, "")),
              url:c.url||"",
              logo:c.logo||""
            };
          }).filter(c=>c.url);
        }
      }
    } catch (e) {
      console.warn("Worker playlist bootstrap unavailable.", e);
    }
  }

  throw new Error("Playlist load failed");
}

async function refreshVipPlaylist() {
  try {
    const fresh = await fetchPlaylistFromGithub();
    const oldCurrentName = currentChannelName ? currentChannelName() : "";
    const oldWasFallback = currentChannelUrl ? currentChannelUrl() === STREAM_FALLBACK_URL : false;

    channels = fresh;
    saveLastGoodPlaylist(fresh);
    render();

    if (oldCurrentName && oldWasFallback) {
      const updated = channels.find(function(c){ return c.name === oldCurrentName; });
      if (updated) play(updated, null, true);
    }

    console.log("VIP playlist auto-refreshed:", channels.length);
    return true;
  } catch (e) {
    console.warn("VIP playlist refresh failed; keeping current playlist.", e);
    return false;
  }
}

setInterval(refreshVipPlaylist, PLAYLIST_REFRESH_MS);

(function () {
  var s = document.createElement("style");
  s.textContent = ".headline-track span{color:#fff !important;}";
  document.head.appendChild(s);
})();

async function loadVipNotice() {
  const apiBase = (window.VIP_WORKER_API || "").replace(/\/$/, "");
  if (!apiBase) return;
  try {
    const r = await fetch(apiBase + "/api/state", {cache:"no-store"});
    if (!r.ok) return;
    const data = await r.json();
    const notice = data.notice || {};
    const text = notice.enabled === false ? "" : String(notice.text || data.headline || "");
    const track = document.querySelector(".headline-track");
    if (track && text) track.innerHTML = "<span>"+esc(text)+"</span><span>"+esc(text)+"</span>";
  } catch (e) {}
}

loadChannelAccess().then(function(){
  return Promise.all([loadVipPlaylist(), loadVipNotice()]);
}).then(function (result) {
  const parsed = result[0];
  if (!parsed.length) throw new Error("No valid channels");
  channels = parsed;
  render();
}).catch(function (error) {
  console.error(error);
  empty.hidden = false;
  empty.textContent = "Playlist load করা যায়নি। M3U link check করুন।";
});

/* paid-crown init above */
/* ORIGINAL Promise.all replaced */
/* __END_PAID_PATCH__ */
/* V14: keep the page as a real root document scroll. Android Chrome can only
   collapse its address/search bar from root-page scrolling, not from a nested
   fixed #grid scroller. */
document.addEventListener("DOMContentLoaded", function(){
  const w=document.getElementById("welcomeVideo");
  const vb=w && w.closest(".video-box");
  if(w && vb && w.parentElement!==vb) vb.insertBefore(w,vb.firstChild);
  document.documentElement.style.overflowX="hidden";
  document.documentElement.style.overflowY="auto";
  document.body.style.overflowX="hidden";
  document.body.style.overflowY="auto";
  document.body.style.position="static";
  document.body.style.inset="auto";
});

// V12: block Android Chrome's native long-press video menu (Copy video frame / PiP)
// without disabling our normal tap-to-toggle controls.
(function preventNativeVideoLongPressMenu(){
  const targets = [
    document.getElementById("video"),
    document.getElementById("welcomeVideo"),
    document.getElementById("vipVideoBox")
  ].filter(Boolean);

  targets.forEach(function(el){
    ["contextmenu", "selectstart", "dragstart"].forEach(function(type){
      el.addEventListener(type, function(e){
        e.preventDefault();
        e.stopPropagation();
        return false;
      }, {capture:true});
    });
  });

  // Keep long-press from being interpreted as a text/drag gesture on touch devices.
  let touchStartAt = 0;
  let touchMoved = false;
  const box = document.getElementById("vipVideoBox");
  if (!box) return;

  box.addEventListener("touchstart", function(){
    touchStartAt = Date.now();
    touchMoved = false;
  }, {passive:true});
  box.addEventListener("touchmove", function(){
    touchMoved = true;
  }, {passive:true});
  box.addEventListener("touchend", function(){
    touchStartAt = 0;
    touchMoved = false;
  }, {passive:true});
})();


window.addEventListener("resize", function () {
  fitChannelLabels(document);
});

window.addEventListener("load", function () {
  fitChannelLabels(document);
});
