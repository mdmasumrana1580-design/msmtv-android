package tv.msm.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val homeUrl = "https://msm.masum-tv.workers.dev/"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        web = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            settings.allowFileAccess = false
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url?.toString() ?: return false
                    return !(url.startsWith("https://msm.masum-tv.workers.dev/") || url.startsWith("https://"))
                }
                override fun onPageFinished(view: WebView?, url: String?) { super.onPageFinished(view, url); injectRemoteControlSupport() }
            }
        }
        setContentView(web)
        if (savedInstanceState == null) web.loadUrl(homeUrl) else web.restoreState(savedInstanceState)
    }

    private fun injectRemoteControlSupport() {
        web.evaluateJavascript("""(function(){
          if(window.__msmTvKeysReady)return; window.__msmTvKeysReady=true;
          const selector='.card, .cats button, #closePlayer, #prevChannel, #nextChannel, #vipMute, #vipFullscreen, .catalogue-load-more, button, a, input';
          function items(){return [...document.querySelectorAll(selector)].filter(e=>e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden'&&!e.disabled)}
          function prep(){items().forEach(e=>{if(!e.hasAttribute('tabindex'))e.setAttribute('tabindex','0')})}
          function move(key){prep();const a=document.activeElement,all=items();if(!all.includes(a)){(all.find(e=>e.classList.contains('card'))||all[0])?.focus();return}
            const r=a.getBoundingClientRect(),x=r.left+r.width/2,y=r.top+r.height/2,d={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[key];
            const c=all.filter(e=>e!==a).map(e=>{const q=e.getBoundingClientRect(),dx=q.left+q.width/2-x,dy=q.top+q.height/2-y,p=dx*d[0]+dy*d[1],cross=Math.abs(dx*d[1]-dy*d[0]);return {e,s:p>2?p+cross*2:Infinity}}).sort((u,v)=>u.s-v.s);if(c[0]&&Number.isFinite(c[0].s))c[0].e.focus();}
          document.addEventListener('keydown',e=>{if(/^Arrow/.test(e.key)){e.preventDefault();move(e.key)}else if(e.key==='Enter'&&document.activeElement!==document.body){document.activeElement.click()}else if(e.key==='Escape'){document.getElementById('closePlayer')?.click()}},true);
          new MutationObserver(prep).observe(document.documentElement,{childList:true,subtree:true});prep();
          const s=document.createElement('style');s.textContent=selector+':focus-visible{outline:3px solid #16c7ff!important;outline-offset:4px!important;transform:scale(1.035);z-index:10}';document.head.appendChild(s);
        })();""".trimIndent(), null)
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (::web.isInitialized && keyCode == KeyEvent.KEYCODE_BACK && web.canGoBack()) { web.goBack(); return true }
        return super.onKeyDown(keyCode, event)
    }
    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); if (::web.isInitialized) web.saveState(outState) }
    override fun onDestroy() { if (::web.isInitialized) web.destroy(); super.onDestroy() }
}
