MsM.Tv Android wrapper source

এই ফোল্ডারে একই ওয়েব অ্যাপের দুটি Android build variant আছে:
- mobileDebug / mobileRelease : Android ফোন
- tvDebug / tvRelease : Android TV / Google TV / Android TV Box

অ্যাপটি বর্তমানে https://msm.masum-tv.workers.dev/ ওয়েবসাইট লোড করে। তাই ওয়েবসাইটটি অনলাইনে প্রকাশিত ও সচল থাকতে হবে।

APK তৈরি করতে:
1) Android Studio-তে android ফোল্ডারটি Open করুন।
2) Gradle Sync সম্পন্ন করুন (JDK 17 এবং Android SDK 35 প্রয়োজন)।
3) Build > Generate App Bundles or APKs > Build APKs নির্বাচন করুন।
   অথবা টার্মিনালে চালান: ./gradlew assembleMobileDebug assembleTvDebug

APK output:
app/build/outputs/apk/mobile/debug/app-mobile-debug.apk
app/build/outputs/apk/tv/debug/app-tv-debug.apk

নোট:
- এটি Android Studio-তে build করার source project, প্রস্তুত APK নয়। এই পরিবেশে Android SDK/Gradle নেই, তাই APK compile/test করা হয়নি।
- TV flavor landscape, Leanback launcher feature ও remote/D-pad focus navigation যোগ করে।
- Samsung Tizen এবং LG webOS-এর জন্য আলাদা SDK/প্যাকেজিং ও TV-তে পরীক্ষা লাগবে।
- Store প্রকাশের আগে signing key, privacy policy, app icon/banner এবং playback/device compatibility পরীক্ষা প্রয়োজন।
